export interface Song {
  id: string;
  title: string;
  artist: string;
  movie?: string;
  album?: string;
  duration: number; // in seconds
  audioUrl: string;
  artUrl: string;
  isDownloaded: boolean;
  downloadedAt?: string;
  fileSizeMb: number;
  localBlob?: Blob;
  localPath?: string;
  isFavorite?: boolean;
  lyrics?: string[];
  bitRate?: string;
  genre?: string;
  playsCount?: number;
  synthTheme?: 'romantic_acoustic' | 'lofi_chill' | 'cinematic_strings' | 'piano_ballad' | 'rnb_slow';
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  coverUrl?: string;
  songIds: string[];
  isOffline: boolean;
  createdAt: string;
}

export type RepeatMode = 'off' | 'all' | 'one';

export interface PlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  repeatMode: RepeatMode;
  isShuffled: boolean;
  playbackRate: number;
  isOfflineMode: boolean; // Airplane Mode simulated
  activeAudioSource: 'local' | 'cloud' | 'synth';
  currentSongIndex: number;
}

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // -12 to 12 dB
}

export interface EqualizerPreset {
  id: string;
  name: string;
  gains: [number, number, number, number, number];
}

export type TabType = 'library' | 'playlists' | 'search' | 'storage' | 'architecture';

export interface StorageStats {
  usedMb: number;
  totalQuotaMb: number;
  downloadedSongsCount: number;
  totalSongsCount: number;
  cacheMb: number;
}
