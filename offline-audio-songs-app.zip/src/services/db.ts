import { Song, Playlist } from '../types';
import { INITIAL_SONGS, INITIAL_PLAYLISTS } from '../data/mockSongs';

const DB_NAME = 'AuraSound_OfflineDB';
const DB_VERSION = 1;

export class LocalStorageDatabase {
  private static instance: LocalStorageDatabase;
  private db: IDBDatabase | null = null;

  private constructor() {}

  public static getInstance(): LocalStorageDatabase {
    if (!LocalStorageDatabase.instance) {
      LocalStorageDatabase.instance = new LocalStorageDatabase();
    }
    return LocalStorageDatabase.instance;
  }

  public async init(): Promise<void> {
    if (this.db) return;

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('songs')) {
          db.createObjectStore('songs', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('audio_blobs')) {
          db.createObjectStore('audio_blobs', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('playlists')) {
          db.createObjectStore('playlists', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('history')) {
          db.createObjectStore('history', { keyPath: 'songId' });
        }
      };

      request.onsuccess = async (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        // Seed initial data if empty
        const songs = await this.getAllSongs();
        if (songs.length === 0) {
          for (const s of INITIAL_SONGS) {
            await this.saveSong(s);
          }
          for (const p of INITIAL_PLAYLISTS) {
            await this.savePlaylist(p);
          }
        }
        resolve();
      };

      request.onerror = () => {
        console.warn('IndexedDB unavailable, falling back to localStorage');
        resolve();
      };
    });
  }

  public async getAllSongs(): Promise<Song[]> {
    if (!this.db) {
      const cached = localStorage.getItem('aurasound_songs');
      return cached ? JSON.parse(cached) : INITIAL_SONGS;
    }

    return new Promise((resolve) => {
      const transaction = this.db!.transaction('songs', 'readonly');
      const store = transaction.objectStore('songs');
      const request = store.getAll();

      request.onsuccess = () => {
        resolve(request.result || []);
      };
      request.onerror = () => {
        resolve(INITIAL_SONGS);
      };
    });
  }

  public async saveSong(song: Song): Promise<void> {
    if (!this.db) {
      const current = await this.getAllSongs();
      const idx = current.findIndex((s) => s.id === song.id);
      if (idx >= 0) current[idx] = song;
      else current.push(song);
      localStorage.setItem('aurasound_songs', JSON.stringify(current));
      return;
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction('songs', 'readwrite');
      const store = transaction.objectStore('songs');
      const request = store.put(song);
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e);
    });
  }

  public async deleteSong(id: string): Promise<void> {
    if (!this.db) {
      const current = (await this.getAllSongs()).filter((s) => s.id !== id);
      localStorage.setItem('aurasound_songs', JSON.stringify(current));
      return;
    }

    return new Promise((resolve) => {
      const transaction = this.db!.transaction(['songs', 'audio_blobs'], 'readwrite');
      transaction.objectStore('songs').delete(id);
      transaction.objectStore('audio_blobs').delete(id);
      transaction.oncomplete = () => resolve();
    });
  }

  public async saveAudioBlob(id: string, blob: Blob): Promise<void> {
    if (!this.db) return;
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction('audio_blobs', 'readwrite');
      const store = transaction.objectStore('audio_blobs');
      const request = store.put({ id, blob });
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e);
    });
  }

  public async getAudioBlob(id: string): Promise<Blob | null> {
    if (!this.db) return null;
    return new Promise((resolve) => {
      const transaction = this.db!.transaction('audio_blobs', 'readonly');
      const store = transaction.objectStore('audio_blobs');
      const request = store.get(id);
      request.onsuccess = () => {
        resolve(request.result?.blob || null);
      };
      request.onerror = () => resolve(null);
    });
  }

  public async removeAudioBlob(id: string): Promise<void> {
    if (!this.db) return;
    return new Promise((resolve) => {
      const transaction = this.db!.transaction('audio_blobs', 'readwrite');
      const store = transaction.objectStore('audio_blobs');
      store.delete(id);
      transaction.oncomplete = () => resolve();
    });
  }

  public async getAllPlaylists(): Promise<Playlist[]> {
    if (!this.db) {
      const cached = localStorage.getItem('aurasound_playlists');
      return cached ? JSON.parse(cached) : INITIAL_PLAYLISTS;
    }

    return new Promise((resolve) => {
      const transaction = this.db!.transaction('playlists', 'readonly');
      const store = transaction.objectStore('playlists');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => resolve(INITIAL_PLAYLISTS);
    });
  }

  public async savePlaylist(playlist: Playlist): Promise<void> {
    if (!this.db) {
      const current = await this.getAllPlaylists();
      const idx = current.findIndex((p) => p.id === playlist.id);
      if (idx >= 0) current[idx] = playlist;
      else current.push(playlist);
      localStorage.setItem('aurasound_playlists', JSON.stringify(current));
      return;
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction('playlists', 'readwrite');
      const store = transaction.objectStore('playlists');
      const request = store.put(playlist);
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e);
    });
  }

  public async deletePlaylist(id: string): Promise<void> {
    if (!this.db) {
      const current = (await this.getAllPlaylists()).filter((p) => p.id !== id);
      localStorage.setItem('aurasound_playlists', JSON.stringify(current));
      return;
    }

    return new Promise((resolve) => {
      const transaction = this.db!.transaction('playlists', 'readwrite');
      transaction.objectStore('playlists').delete(id);
      transaction.oncomplete = () => resolve();
    });
  }

  public async recordHistory(songId: string): Promise<void> {
    if (!this.db) return;
    try {
      const transaction = this.db.transaction('history', 'readwrite');
      transaction.objectStore('history').put({ songId, timestamp: new Date().toISOString() });
    } catch {
      // ignore
    }
  }

  public async clearAllCache(): Promise<void> {
    const songs = await this.getAllSongs();
    for (const song of songs) {
      if (song.isDownloaded) {
        song.isDownloaded = false;
        song.localPath = undefined;
        song.downloadedAt = undefined;
        await this.saveSong(song);
        await this.removeAudioBlob(song.id);
      }
    }
  }
}

export const localDB = LocalStorageDatabase.getInstance();
