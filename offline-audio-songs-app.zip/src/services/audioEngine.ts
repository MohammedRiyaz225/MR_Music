import { Song, EqualizerBand, EqualizerPreset } from '../types';
import { localDB } from './db';

export const EQUALIZER_PRESETS: EqualizerPreset[] = [
  { id: 'flat', name: 'Flat / Studio', gains: [0, 0, 0, 0, 0] },
  { id: 'romantic', name: 'Telugu Romance & Melodies', gains: [4, 2, 3, 5, 4] },
  { id: 'bass', name: 'Deep Bass Boost', gains: [8, 5, 0, -2, -3] },
  { id: 'vocal', name: 'Vocal Clarity', gains: [-2, 1, 6, 4, 1] },
  { id: 'acoustic', name: 'Acoustic & Guitar Plucks', gains: [3, 2, 4, 5, 6] },
  { id: 'electronic', name: 'Electronic Dance', gains: [6, 4, -1, 3, 5] },
];

export class AudioEngine {
  private static instance: AudioEngine;
  private audioCtx: AudioContext | null = null;
  private audioElement: HTMLAudioElement | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private gainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];

  // Synth state for synthesized music generation
  private isSynthPlaying = false;
  private synthInterval: number | null = null;
  private synthGainNode: GainNode | null = null;
  private activeOscillators: OscillatorNode[] = [];

  private currentSong: Song | null = null;
  private onTimeUpdateCallback?: (currentTime: number, duration: number) => void;
  private onEndedCallback?: () => void;
  private onErrorCallback?: (err: string) => void;

  public equalizerBands: EqualizerBand[] = [
    { frequency: 60, label: '60 Hz (Sub Bass)', gain: 4 },
    { frequency: 230, label: '230 Hz (Bass)', gain: 2 },
    { frequency: 910, label: '910 Hz (Mid)', gain: 3 },
    { frequency: 3600, label: '3.6 kHz (High-Mid)', gain: 5 },
    { frequency: 14000, label: '14 kHz (Treble)', gain: 4 },
  ];

  private constructor() {
    this.audioElement = new Audio();
    this.audioElement.crossOrigin = 'anonymous';
    this.audioElement.preload = 'auto';

    this.audioElement.addEventListener('timeupdate', () => {
      if (this.audioElement && this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(
          this.audioElement.currentTime,
          this.audioElement.duration || this.currentSong?.duration || 240
        );
      }
    });

    this.audioElement.addEventListener('ended', () => {
      if (this.onEndedCallback) {
        this.onEndedCallback();
      }
    });

    this.audioElement.addEventListener('error', () => {
      // Fallback to synth if external file stream fails
      if (this.currentSong && !this.isSynthPlaying) {
        this.startSynthMelody(this.currentSong);
      }
    });
  }

  public static getInstance(): AudioEngine {
    if (!AudioEngine.instance) {
      AudioEngine.instance = new AudioEngine();
    }
    return AudioEngine.instance;
  }

  private initAudioContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();

      this.gainNode = this.audioCtx.createGain();
      this.synthGainNode = this.audioCtx.createGain();
      this.synthGainNode.gain.value = 0.25;

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.8;

      // Create 5-band equalizer
      const freqs = [60, 230, 910, 3600, 14000];
      const types: BiquadFilterType[] = ['lowshelf', 'peaking', 'peaking', 'peaking', 'highshelf'];

      this.eqFilters = freqs.map((freq, i) => {
        const filter = this.audioCtx!.createBiquadFilter();
        filter.type = types[i];
        filter.frequency.value = freq;
        filter.gain.value = this.equalizerBands[i].gain;
        return filter;
      });

      // Chain EQ filters
      for (let i = 0; i < this.eqFilters.length - 1; i++) {
        this.eqFilters[i].connect(this.eqFilters[i + 1]);
      }

      // Connect last filter to analyser and destination
      const lastFilter = this.eqFilters[this.eqFilters.length - 1];
      lastFilter.connect(this.analyserNode);
      this.analyserNode.connect(this.gainNode);
      this.gainNode.connect(this.audioCtx.destination);

      // Connect synth gain to first EQ filter so synth also gets equalized!
      this.synthGainNode.connect(this.eqFilters[0]);

      if (this.audioElement) {
        try {
          this.sourceNode = this.audioCtx.createMediaElementSource(this.audioElement);
          this.sourceNode.connect(this.eqFilters[0]);
        } catch {
          // If media element already connected, ignore
        }
      }
    }

    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setCallbacks(
    onTimeUpdate: (currentTime: number, duration: number) => void,
    onEnded: () => void,
    onError: (err: string) => void
  ) {
    this.onTimeUpdateCallback = onTimeUpdate;
    this.onEndedCallback = onEnded;
    this.onErrorCallback = onError;
  }

  public async playSong(
    song: Song,
    isOfflineMode: boolean,
    fromPosition?: number
  ): Promise<'local' | 'cloud' | 'synth'> {
    this.initAudioContext();
    this.stopSynthMelody();

    this.currentSong = song;

    // Check 1: Do we have a local audio blob saved in IndexedDB?
    const localBlob = await localDB.getAudioBlob(song.id);

    if (localBlob) {
      const blobUrl = URL.createObjectURL(localBlob);
      this.audioElement!.src = blobUrl;
      if (fromPosition !== undefined) {
        this.audioElement!.currentTime = fromPosition;
      }
      try {
        await this.audioElement!.play();
        return 'local';
      } catch {
        return this.startSynthMelody(song, fromPosition);
      }
    }

    // Check 2: If offline mode is ON and not downloaded, we cannot stream from internet
    if (isOfflineMode && !song.isDownloaded) {
      // In offline mode without downloaded file, play synthesized track
      return this.startSynthMelody(song, fromPosition);
    }

    // Check 3: Online stream from URL
    if (song.audioUrl && !isOfflineMode) {
      this.audioElement!.src = song.audioUrl;
      if (fromPosition !== undefined) {
        this.audioElement!.currentTime = fromPosition;
      }
      try {
        await this.audioElement!.play();
        return 'cloud';
      } catch {
        return this.startSynthMelody(song, fromPosition);
      }
    }

    // Default: Fallback to high-quality romantic synthesizer
    return this.startSynthMelody(song, fromPosition);
  }

  public pause(): void {
    if (this.audioElement) {
      this.audioElement.pause();
    }
    if (this.isSynthPlaying) {
      this.stopSynthMelody();
    }
  }

  public resume(): void {
    this.initAudioContext();
    if (this.isSynthPlaying && this.currentSong) {
      this.startSynthMelody(this.currentSong);
    } else if (this.audioElement && this.audioElement.src) {
      this.audioElement.play().catch(() => {
        if (this.currentSong) this.startSynthMelody(this.currentSong);
      });
    } else if (this.currentSong) {
      this.startSynthMelody(this.currentSong);
    }
  }

  public seek(seconds: number): void {
    if (this.audioElement && !this.isSynthPlaying) {
      this.audioElement.currentTime = seconds;
    }
    if (this.onTimeUpdateCallback && this.currentSong) {
      this.onTimeUpdateCallback(seconds, this.currentSong.duration);
    }
  }

  public setVolume(volume: number): void {
    if (this.gainNode) {
      this.gainNode.gain.value = Math.max(0, Math.min(1, volume));
    }
    if (this.audioElement) {
      this.audioElement.volume = Math.max(0, Math.min(1, volume));
    }
  }

  public setPlaybackRate(rate: number): void {
    if (this.audioElement) {
      this.audioElement.playbackRate = rate;
    }
  }

  public setEqualizerBand(index: number, gain: number): void {
    if (index >= 0 && index < this.equalizerBands.length) {
      this.equalizerBands[index].gain = gain;
      if (this.eqFilters[index]) {
        this.eqFilters[index].gain.value = gain;
      }
    }
  }

  public applyPreset(preset: EqualizerPreset): void {
    preset.gains.forEach((gain, i) => {
      this.setEqualizerBand(i, gain);
    });
  }

  public getFrequencyData(): Uint8Array {
    if (!this.analyserNode) {
      return new Uint8Array(64).fill(0);
    }
    const data = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(data);
    return data;
  }

  // --- ROMANTIC SYNTHESIZER GENERATOR ---
  // Generates real, soothing, melodic acoustic/piano/lofi harmonies based on the song
  private startSynthMelody(song: Song, startFrom: number = 0): 'synth' {
    this.initAudioContext();
    this.stopSynthMelody();
    this.isSynthPlaying = true;

    let simTime = startFrom;
    const duration = song.duration || 240;

    // Musical chords based on theme
    const themeChords: Record<string, number[][]> = {
      piano_ballad: [
        [261.63, 329.63, 392.0, 523.25], // C major
        [220.0, 261.63, 329.63, 440.0],  // A minor
        [174.61, 220.0, 261.63, 349.23], // F major
        [196.0, 246.94, 293.66, 392.0],  // G major
      ],
      romantic_acoustic: [
        [293.66, 369.99, 440.0, 587.33], // D major
        [246.94, 293.66, 369.99, 493.88], // B minor
        [196.0, 246.94, 293.66, 392.0],  // G major
        [220.0, 277.18, 329.63, 440.0],  // A major
      ],
      rnb_slow: [
        [220.0, 277.18, 329.63, 415.3],  // A maj7
        [185.0, 220.0, 277.18, 329.63],  // F# min7
        [164.81, 207.65, 246.94, 311.13], // E maj7
        [196.0, 246.94, 293.66, 392.0],  // G maj7
      ],
      cinematic_strings: [
        [196.0, 233.08, 293.66, 392.0], // G minor
        [164.81, 196.0, 246.94, 329.63], // Eb major
        [146.83, 174.61, 220.0, 293.66], // D minor
        [130.81, 164.81, 196.0, 261.63], // C minor
      ],
      lofi_chill: [
        [261.63, 311.13, 392.0, 466.16], // C min7
        [174.61, 207.65, 261.63, 311.13], // F min7
        [233.08, 293.66, 349.23, 415.3],  // Bb maj7
        [155.56, 196.0, 233.08, 293.66],  // Eb maj7
      ],
    };

    const chords = themeChords[song.synthTheme || 'romantic_acoustic'] || themeChords.romantic_acoustic;
    let step = 0;

    const playStep = () => {
      if (!this.isSynthPlaying || !this.audioCtx) return;

      const chordIndex = Math.floor(step / 4) % chords.length;
      const currentChord = chords[chordIndex];
      const noteFreq = currentChord[step % currentChord.length];

      // Play melody note
      this.triggerSynthNote(noteFreq, 0.4, 'sine');

      // Play soft bass root note on first beat
      if (step % 4 === 0) {
        this.triggerSynthNote(currentChord[0] / 2, 1.2, 'triangle', 0.2);
        // Play chord pad
        currentChord.forEach((f) => {
          this.triggerSynthNote(f, 0.8, 'sine', 0.05);
        });
      }

      step++;
      simTime += 0.35;

      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(simTime, duration);
      }

      if (simTime >= duration) {
        this.stopSynthMelody();
        if (this.onEndedCallback) {
          this.onEndedCallback();
        }
      }
    };

    this.synthInterval = window.setInterval(playStep, 350);
    return 'synth';
  }

  private triggerSynthNote(freq: number, duration: number, type: OscillatorType = 'sine', vol = 0.15) {
    if (!this.audioCtx || !this.synthGainNode) return;

    try {
      const osc = this.audioCtx.createOscillator();
      const noteGain = this.audioCtx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);

      noteGain.gain.setValueAtTime(0, this.audioCtx.currentTime);
      noteGain.gain.linearRampToValueAtTime(vol, this.audioCtx.currentTime + 0.05);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + duration);

      osc.connect(noteGain);
      noteGain.connect(this.synthGainNode);

      osc.start();
      osc.stop(this.audioCtx.currentTime + duration);

      this.activeOscillators.push(osc);
      setTimeout(() => {
        const idx = this.activeOscillators.indexOf(osc);
        if (idx >= 0) this.activeOscillators.splice(idx, 1);
      }, duration * 1000 + 100);
    } catch {
      // Audio node cleanup
    }
  }

  private stopSynthMelody() {
    this.isSynthPlaying = false;
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.activeOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // ignore
      }
    });
    this.activeOscillators = [];
  }
}

export const audioEngine = AudioEngine.getInstance();
