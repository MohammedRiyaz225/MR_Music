import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { Song, Playlist, PlaybackState, TabType, StorageStats } from '../types';
import { localDB } from '../services/db';
import { audioEngine, EQUALIZER_PRESETS } from '../services/audioEngine';

interface MusicContextType {
  songs: Song[];
  playlists: Playlist[];
  currentSong: Song | null;
  queue: Song[];
  playbackState: PlaybackState;
  downloadProgress: Record<string, number>;
  storageStats: StorageStats;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  isFullPlayerOpen: boolean;
  setIsFullPlayerOpen: (open: boolean) => void;
  isEqualizerOpen: boolean;
  setIsEqualizerOpen: (open: boolean) => void;
  isUploadModalOpen: boolean;
  setIsUploadModalOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  syncStatus: 'synced' | 'syncing' | 'offline' | 'pending';
  deviceMode: 'mobile-frame' | 'responsive';
  setDeviceMode: (mode: 'mobile-frame' | 'responsive') => void;
  
  // Player Actions
  playSong: (song: Song) => Promise<void>;
  togglePlayPause: () => void;
  skipNext: () => void;
  skipPrevious: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeatMode: () => void;
  setPlaybackRate: (rate: number) => void;
  toggleFavorite: (songId: string) => Promise<void>;

  // Offline & Storage Actions
  toggleOfflineMode: () => void;
  downloadSong: (song: Song) => Promise<void>;
  deleteDownload: (songId: string) => Promise<void>;
  downloadAllOffline: () => Promise<void>;
  clearOfflineStorage: () => Promise<void>;
  uploadNewSong: (data: { file?: File; title: string; artist: string; movie?: string; genre?: string; artUrl?: string }) => Promise<void>;
  syncWithCloud: () => Promise<void>;
  
  // Playlists
  createPlaylist: (name: string, description: string, songIds: string[]) => Promise<void>;
  deletePlaylist: (playlistId: string) => Promise<void>;
  togglePlaylistOffline: (playlistId: string) => Promise<void>;
}

const MusicContext = createContext<MusicContextType | null>(null);

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [songs, setSongs] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [queue, setQueue] = useState<Song[]>([]);
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({});
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'offline' | 'pending'>('synced');
  
  const [activeTab, setActiveTab] = useState<TabType>('library');
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [deviceMode, setDeviceMode] = useState<'mobile-frame' | 'responsive'>('mobile-frame');

  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    currentTime: 0,
    duration: 240,
    volume: 0.85,
    isMuted: false,
    repeatMode: 'off',
    isShuffled: false,
    playbackRate: 1.0,
    isOfflineMode: false,
    activeAudioSource: 'synth',
    currentSongIndex: 0,
  });

  const [storageStats, setStorageStats] = useState<StorageStats>({
    usedMb: 34.3,
    totalQuotaMb: 10240, // 10 GB
    downloadedSongsCount: 4,
    totalSongsCount: 8,
    cacheMb: 12.4,
  });

  // Keep ref of latest state for callbacks
  const stateRef = useRef({
    songs,
    queue,
    currentSong,
    playbackState,
  });
  stateRef.current = { songs, queue, currentSong, playbackState };

  // Calculate storage stats
  const calculateStorage = useCallback((songList: Song[]) => {
    const downloaded = songList.filter((s) => s.isDownloaded);
    const used = downloaded.reduce((acc, s) => acc + (s.fileSizeMb || 7.5), 0);
    setStorageStats({
      usedMb: parseFloat(used.toFixed(1)),
      totalQuotaMb: 10240,
      downloadedSongsCount: downloaded.length,
      totalSongsCount: songList.length,
      cacheMb: parseFloat((used * 0.15).toFixed(1)),
    });
  }, []);

  // Initialize DB and Audio Callbacks
  useEffect(() => {
    const initApp = async () => {
      await localDB.init();
      const allSongs = await localDB.getAllSongs();
      const allPlaylists = await localDB.getAllPlaylists();
      setSongs(allSongs);
      setPlaylists(allPlaylists);
      setQueue(allSongs);
      calculateStorage(allSongs);

      if (allSongs.length > 0) {
        setCurrentSong(allSongs[0]);
      }
    };
    initApp();

    audioEngine.setCallbacks(
      (currentTime, duration) => {
        setPlaybackState((prev) => ({
          ...prev,
          currentTime,
          duration: duration || prev.duration,
        }));
      },
      () => {
        // Track ended
        handleTrackEnded();
      },
      (err) => {
        console.warn('Audio playback notice:', err);
      }
    );

    // Apply romantic EQ preset as default
    audioEngine.applyPreset(EQUALIZER_PRESETS[1]);
  }, [calculateStorage]);

  const handleTrackEnded = () => {
    const { queue, currentSong, playbackState } = stateRef.current;
    if (playbackState.repeatMode === 'one' && currentSong) {
      playSong(currentSong);
      return;
    }

    const currentIndex = queue.findIndex((s) => s.id === currentSong?.id);
    if (currentIndex < queue.length - 1) {
      playSong(queue[currentIndex + 1]);
    } else if (playbackState.repeatMode === 'all' && queue.length > 0) {
      playSong(queue[0]);
    } else {
      setPlaybackState((prev) => ({ ...prev, isPlaying: false, currentTime: 0 }));
      audioEngine.pause();
    }
  };

  const playSong = async (song: Song) => {
    setCurrentSong(song);
    const source = await audioEngine.playSong(song, playbackState.isOfflineMode);
    
    setPlaybackState((prev) => ({
      ...prev,
      isPlaying: true,
      duration: song.duration,
      activeAudioSource: source,
      currentSongIndex: queue.findIndex((s) => s.id === song.id),
    }));

    // Record play count and history
    song.playsCount = (song.playsCount || 0) + 1;
    await localDB.saveSong(song);
    await localDB.recordHistory(song.id);
  };

  const togglePlayPause = () => {
    if (!currentSong && songs.length > 0) {
      playSong(songs[0]);
      return;
    }

    if (playbackState.isPlaying) {
      audioEngine.pause();
      setPlaybackState((prev) => ({ ...prev, isPlaying: false }));
    } else {
      audioEngine.resume();
      setPlaybackState((prev) => ({ ...prev, isPlaying: true }));
    }
  };

  const skipNext = () => {
    if (queue.length === 0) return;
    const currentIndex = queue.findIndex((s) => s.id === currentSong?.id);
    let nextIndex = currentIndex + 1;
    if (nextIndex >= queue.length) {
      nextIndex = 0;
    }
    playSong(queue[nextIndex]);
  };

  const skipPrevious = () => {
    if (queue.length === 0) return;
    if (playbackState.currentTime > 3) {
      seekTo(0);
      return;
    }
    const currentIndex = queue.findIndex((s) => s.id === currentSong?.id);
    let prevIndex = currentIndex - 1;
    if (prevIndex < 0) {
      prevIndex = queue.length - 1;
    }
    playSong(queue[prevIndex]);
  };

  const seekTo = (seconds: number) => {
    audioEngine.seek(seconds);
    setPlaybackState((prev) => ({ ...prev, currentTime: seconds }));
  };

  const setVolume = (vol: number) => {
    audioEngine.setVolume(vol);
    setPlaybackState((prev) => ({ ...prev, volume: vol, isMuted: vol === 0 }));
  };

  const toggleMute = () => {
    if (playbackState.isMuted) {
      audioEngine.setVolume(playbackState.volume || 0.8);
      setPlaybackState((prev) => ({ ...prev, isMuted: false }));
    } else {
      audioEngine.setVolume(0);
      setPlaybackState((prev) => ({ ...prev, isMuted: true }));
    }
  };

  const toggleShuffle = () => {
    setPlaybackState((prev) => {
      const nextShuffled = !prev.isShuffled;
      if (nextShuffled) {
        const shuffled = [...songs].sort(() => Math.random() - 0.5);
        setQueue(shuffled);
      } else {
        setQueue(songs);
      }
      return { ...prev, isShuffled: nextShuffled };
    });
  };

  const cycleRepeatMode = () => {
    setPlaybackState((prev) => {
      const modes: PlaybackState['repeatMode'][] = ['off', 'all', 'one'];
      const nextIndex = (modes.indexOf(prev.repeatMode) + 1) % modes.length;
      return { ...prev, repeatMode: modes[nextIndex] };
    });
  };

  const setPlaybackRate = (rate: number) => {
    audioEngine.setPlaybackRate(rate);
    setPlaybackState((prev) => ({ ...prev, playbackRate: rate }));
  };

  const toggleFavorite = async (songId: string) => {
    const updated = songs.map((s) => {
      if (s.id === songId) {
        return { ...s, isFavorite: !s.isFavorite };
      }
      return s;
    });
    setSongs(updated);
    const target = updated.find((s) => s.id === songId);
    if (target) {
      await localDB.saveSong(target);
    }
  };

  const toggleOfflineMode = () => {
    setPlaybackState((prev) => {
      const nextMode = !prev.isOfflineMode;
      setSyncStatus(nextMode ? 'offline' : 'synced');
      return { ...prev, isOfflineMode: nextMode };
    });
  };

  // Download simulation with real progress + blob caching
  const downloadSong = async (song: Song) => {
    if (song.isDownloaded || downloadProgress[song.id] !== undefined) return;

    setDownloadProgress((prev) => ({ ...prev, [song.id]: 5 }));

    // Simulate chunked download progress
    for (let p = 15; p <= 100; p += 15) {
      await new Promise((r) => setTimeout(r, 120));
      setDownloadProgress((prev) => ({ ...prev, [song.id]: p }));
    }

    try {
      // Try to fetch audio blob or create synthetic audio blob
      let audioBlob: Blob;
      try {
        const res = await fetch(song.audioUrl);
        audioBlob = await res.blob();
      } catch {
        audioBlob = new Blob(['Offline Audio Binary Mock Cache'], { type: 'audio/mp3' });
      }

      await localDB.saveAudioBlob(song.id, audioBlob);

      const updatedSong: Song = {
        ...song,
        isDownloaded: true,
        downloadedAt: new Date().toISOString(),
        localPath: `/storage/emulated/0/Music/${song.title.replace(/\s+/g, '_')}.mp3`,
      };

      await localDB.saveSong(updatedSong);

      setSongs((prev) => prev.map((s) => (s.id === song.id ? updatedSong : s)));
      if (currentSong?.id === song.id) {
        setCurrentSong(updatedSong);
      }
      calculateStorage(songs.map((s) => (s.id === song.id ? updatedSong : s)));
    } finally {
      setDownloadProgress((prev) => {
        const next = { ...prev };
        delete next[song.id];
        return next;
      });
    }
  };

  const deleteDownload = async (songId: string) => {
    await localDB.removeAudioBlob(songId);
    const updated = songs.map((s) => {
      if (s.id === songId) {
        return {
          ...s,
          isDownloaded: false,
          downloadedAt: undefined,
          localPath: undefined,
        };
      }
      return s;
    });

    setSongs(updated);
    const target = updated.find((s) => s.id === songId);
    if (target) await localDB.saveSong(target);
    calculateStorage(updated);
  };

  const downloadAllOffline = async () => {
    const toDownload = songs.filter((s) => !s.isDownloaded);
    for (const song of toDownload) {
      await downloadSong(song);
    }
  };

  const clearOfflineStorage = async () => {
    await localDB.clearAllCache();
    const refreshed = await localDB.getAllSongs();
    setSongs(refreshed);
    calculateStorage(refreshed);
  };

  const uploadNewSong = async (data: {
    file?: File;
    title: string;
    artist: string;
    movie?: string;
    genre?: string;
    artUrl?: string;
  }) => {
    const id = `user-song-${Date.now()}`;
    let blob: Blob | undefined;
    let url = 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=melody.mp3';

    if (data.file) {
      blob = data.file;
      url = URL.createObjectURL(data.file);
      await localDB.saveAudioBlob(id, blob);
    }

    const newSong: Song = {
      id,
      title: data.title || 'Untitled Melody',
      artist: data.artist || 'Personal Collection',
      movie: data.movie || 'Private Library',
      album: data.movie ? `${data.movie} OST` : 'User Uploads',
      duration: 220,
      audioUrl: url,
      artUrl:
        data.artUrl ||
        'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
      isDownloaded: true,
      downloadedAt: new Date().toISOString(),
      fileSizeMb: data.file ? parseFloat((data.file.size / (1024 * 1024)).toFixed(1)) : 8.2,
      localPath: `/storage/emulated/0/Music/${(data.title || 'song').replace(/\s+/g, '_')}.mp3`,
      isFavorite: true,
      genre: data.genre || 'Telugu Melody',
      bitRate: '320 kbps',
      playsCount: 0,
      synthTheme: 'romantic_acoustic',
      lyrics: ['Self-uploaded audio track', 'Playing crystal-clear from phone storage'],
    };

    await localDB.saveSong(newSong);
    const updatedSongs = [newSong, ...songs];
    setSongs(updatedSongs);
    setQueue(updatedSongs);
    calculateStorage(updatedSongs);
    playSong(newSong);
  };

  const syncWithCloud = async () => {
    if (playbackState.isOfflineMode) return;
    setSyncStatus('syncing');
    await new Promise((r) => setTimeout(r, 1200));
    setSyncStatus('synced');
  };

  const createPlaylist = async (name: string, description: string, songIds: string[]) => {
    const newPlaylist: Playlist = {
      id: `pl-${Date.now()}`,
      name,
      description,
      songIds,
      isOffline: true,
      coverUrl:
        songs.find((s) => songIds.includes(s.id))?.artUrl ||
        'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString(),
    };

    await localDB.savePlaylist(newPlaylist);
    setPlaylists((prev) => [...prev, newPlaylist]);
  };

  const deletePlaylist = async (playlistId: string) => {
    await localDB.deletePlaylist(playlistId);
    setPlaylists((prev) => prev.filter((p) => p.id !== playlistId));
  };

  const togglePlaylistOffline = async (playlistId: string) => {
    const target = playlists.find((p) => p.id === playlistId);
    if (!target) return;
    const updated = { ...target, isOffline: !target.isOffline };
    await localDB.savePlaylist(updated);
    setPlaylists((prev) => prev.map((p) => (p.id === playlistId ? updated : p)));

    if (updated.isOffline) {
      // Download all songs in this playlist
      const playlistSongs = songs.filter((s) => target.songIds.includes(s.id));
      for (const s of playlistSongs) {
        if (!s.isDownloaded) {
          await downloadSong(s);
        }
      }
    }
  };

  return (
    <MusicContext.Provider
      value={{
        songs,
        playlists,
        currentSong,
        queue,
        playbackState,
        downloadProgress,
        storageStats,
        activeTab,
        setActiveTab,
        isFullPlayerOpen,
        setIsFullPlayerOpen,
        isEqualizerOpen,
        setIsEqualizerOpen,
        isUploadModalOpen,
        setIsUploadModalOpen,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        syncStatus,
        deviceMode,
        setDeviceMode,
        playSong,
        togglePlayPause,
        skipNext,
        skipPrevious,
        seekTo,
        setVolume,
        toggleMute,
        toggleShuffle,
        cycleRepeatMode,
        setPlaybackRate,
        toggleFavorite,
        toggleOfflineMode,
        downloadSong,
        deleteDownload,
        downloadAllOffline,
        clearOfflineStorage,
        uploadNewSong,
        syncWithCloud,
        createPlaylist,
        deletePlaylist,
        togglePlaylistOffline,
      }}
    >
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) throw new Error('useMusic must be used within MusicProvider');
  return context;
};
