import React from 'react';
import { Play, Pause, SkipForward, CheckCircle2, Cloud, HardDrive, Sliders } from 'lucide-react';
import { useMusic } from '../context/MusicContext';

export const MiniPlayer: React.FC = () => {
  const {
    currentSong,
    playbackState,
    togglePlayPause,
    skipNext,
    setIsFullPlayerOpen,
    setIsEqualizerOpen,
  } = useMusic();

  if (!currentSong) return null;

  const progressPercent = playbackState.duration
    ? (playbackState.currentTime / playbackState.duration) * 100
    : 0;

  return (
    <div className="relative w-full glass-panel border-t border-purple-500/20 bg-slate-900/95 backdrop-blur-xl select-none z-20 transition-all shadow-lg shadow-black/60">
      {/* Top progress bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-slate-800">
        <div
          className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-400 transition-all duration-200"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Left: Thumbnail and Track info */}
        <div
          onClick={() => setIsFullPlayerOpen(true)}
          className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer group"
        >
          <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 shadow-md border border-white/10 bg-slate-800">
            <img
              src={currentSong.artUrl}
              alt={currentSong.title}
              className={`w-full h-full object-cover transition-transform group-hover:scale-105 ${
                playbackState.isPlaying ? 'animate-spin-slow' : ''
              }`}
            />
            {/* Center vinyl dot */}
            <div className="absolute inset-0 m-auto w-2.5 h-2.5 rounded-full bg-slate-950 border border-purple-400/50 pointer-events-none" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h4 className="text-sm font-semibold text-white truncate group-hover:text-purple-300 transition-colors">
                {currentSong.title}
              </h4>
              {currentSong.isDownloaded ? (
                <span
                  title="Downloaded to Local Storage (SQLite)"
                  className="flex items-center text-emerald-400 flex-shrink-0"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </span>
              ) : (
                <span
                  title="Streaming from Cloud Storage"
                  className="flex items-center text-sky-400 flex-shrink-0"
                >
                  <Cloud className="w-3.5 h-3.5" />
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 truncate">
              <span className="truncate">{currentSong.artist}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                <HardDrive className="w-2.5 h-2.5" />
                {currentSong.isDownloaded ? 'Local Disk' : 'Cloud'}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsEqualizerOpen(true);
            }}
            title="Open Equalizer"
            className="p-2 text-slate-400 hover:text-purple-300 rounded-full transition-colors active:scale-95"
          >
            <Sliders className="w-4 h-4" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              togglePlayPause();
            }}
            className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-purple-900/40 hover:scale-105 active:scale-95 transition-all"
          >
            {playbackState.isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              skipNext();
            }}
            className="p-2 text-slate-300 hover:text-white rounded-full transition-colors active:scale-95"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
