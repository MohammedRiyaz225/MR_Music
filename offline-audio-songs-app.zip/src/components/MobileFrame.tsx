import React from 'react';
import {
  Library,
  ListMusic,
  HardDrive,
  Layers,
  Smartphone,
  Maximize2,
  Minimize2,
  Music2,
  Info,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import { MobileStatusBar } from './MobileStatusBar';
import { MiniPlayer } from './MiniPlayer';
import { LibraryView } from './LibraryView';
import { PlaylistsView } from './PlaylistsView';
import { StorageSettingsView } from './StorageSettingsView';
import { ArchitectureInspectorModal } from './ArchitectureInspectorModal';
import { PlayerView } from './PlayerView';
import { EqualizerModal } from './EqualizerModal';
import { UploadModal } from './UploadModal';

export const MobileFrame: React.FC = () => {
  const { activeTab, setActiveTab, deviceMode, setDeviceMode, currentSong } = useMusic();

  const isPhoneView = deviceMode === 'mobile-frame';

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col items-center justify-center p-0 sm:p-4 text-slate-100 selection:bg-purple-500 selection:text-white">
      {/* Top Bar Switcher & Info (Desktop / Tablet view only) */}
      <header className="w-full max-w-4xl px-4 py-2.5 hidden sm:flex items-center justify-between z-40">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-purple-900/50">
            <Music2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
              <span>AuraSound Mobile</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Offline-First v2.4
              </span>
            </h2>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Self-Purpose Mobile Audio App with SQLite, Cloud Sync & 5-Band DSP
            </p>
          </div>
        </div>

        {/* Viewport switch buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setDeviceMode(isPhoneView ? 'responsive' : 'mobile-frame')}
            className="px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 hover:border-purple-500/40 text-xs font-semibold text-slate-300 hover:text-white transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
            title="Toggle between Mobile Phone Chassis and Full Screen Layout"
          >
            {isPhoneView ? (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-purple-400" />
                <span className="hidden sm:inline">Expanded View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                <span className="hidden sm:inline">Mobile Frame</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Container: Mobile Phone Frame on Desktop or Full Screen on Phone */}
      <main
        className={`w-full transition-all duration-300 relative ${
          isPhoneView
            ? 'sm:max-w-[400px] h-screen sm:h-[820px] sm:max-h-[92vh] sm:rounded-[48px] border-0 sm:border-[8px] sm:border-slate-800/90 sm:shadow-2xl sm:shadow-purple-950/80 overflow-hidden ring-0 sm:ring-1 sm:ring-white/10 bg-slate-950 flex flex-col'
            : 'max-w-4xl h-screen sm:h-[85vh] sm:rounded-3xl border-0 sm:border sm:border-white/10 shadow-2xl overflow-hidden bg-slate-950 flex flex-col'
        }`}
      >
        {/* Status Bar */}
        <MobileStatusBar />

        {/* Dynamic Screen View */}
        <div className="flex-1 flex flex-col min-h-0 relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
          {activeTab === 'library' && <LibraryView />}
          {activeTab === 'playlists' && <PlaylistsView />}
          {activeTab === 'storage' && <StorageSettingsView />}
          {activeTab === 'architecture' && <ArchitectureInspectorModal />}
        </div>

        {/* Persistent Mini Player */}
        <MiniPlayer />

        {/* Bottom Navigation Bar */}
        <nav className="w-full bg-slate-950/95 backdrop-blur-md border-t border-white/10 px-3 py-2 flex items-center justify-around z-20 select-none">
          <button
            onClick={() => setActiveTab('library')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'library'
                ? 'text-purple-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Library className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">Songs</span>
          </button>

          <button
            onClick={() => setActiveTab('playlists')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'playlists'
                ? 'text-purple-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ListMusic className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">Playlists</span>
          </button>

          <button
            onClick={() => setActiveTab('storage')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'storage'
                ? 'text-purple-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">Storage</span>
          </button>

          <button
            onClick={() => setActiveTab('architecture')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'architecture'
                ? 'text-purple-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">Architecture</span>
          </button>
        </nav>

        {/* Modals & Full Screen Overlays */}
        <PlayerView />
        <EqualizerModal />
        <UploadModal />
      </main>
    </div>
  );
};
