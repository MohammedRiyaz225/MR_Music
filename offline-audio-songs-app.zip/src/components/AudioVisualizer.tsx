import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../services/audioEngine';

interface AudioVisualizerProps {
  isPlaying: boolean;
  color?: string;
  barsCount?: number;
  height?: number;
  mode?: 'bars' | 'wave' | 'circle';
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  color = '#a855f7',
  barsCount = 28,
  height = 48,
  mode = 'bars',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const freqData = audioEngine.getFrequencyData();
      const width = canvas.width;
      const h = canvas.height;

      if (mode === 'bars') {
        const barWidth = (width / barsCount) * 0.7;
        const gap = (width / barsCount) * 0.3;

        for (let i = 0; i < barsCount; i++) {
          const dataIndex = Math.floor((i / barsCount) * (freqData.length * 0.6));
          let val = freqData[dataIndex] || 0;

          // If not playing, keep a subtle ambient pulse
          if (!isPlaying) {
            val = Math.sin(Date.now() * 0.003 + i * 0.3) * 6 + 10;
          }

          const barHeight = Math.max(3, (val / 255) * h * 0.95);
          const x = i * (barWidth + gap);
          const y = h - barHeight;

          // Gradient color
          const gradient = ctx.createLinearGradient(0, y, 0, h);
          gradient.addColorStop(0, '#c084fc');
          gradient.addColorStop(0.6, color);
          gradient.addColorStop(1, '#6b21a8');

          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, [2, 2, 0, 0]);
          ctx.fill();
        }
      } else if (mode === 'wave') {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.shadowBlur = 8;
        ctx.shadowColor = color;

        const sliceWidth = width / freqData.length;
        let x = 0;

        for (let i = 0; i < freqData.length; i++) {
          const v = (freqData[i] || 128) / 128.0;
          const y = (v * h) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          x += sliceWidth;
        }

        ctx.lineTo(width, h / 2);
        ctx.stroke();
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, color, barsCount, height, mode]);

  return (
    <canvas
      ref={canvasRef}
      width={barsCount * 8}
      height={height}
      className="w-full pointer-events-none"
      style={{ height: `${height}px` }}
    />
  );
};
