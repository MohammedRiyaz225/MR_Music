import React, { useState } from 'react';
import {
  HardDrive,
  Cloud,
  Database,
  RefreshCw,
  Trash2,
  Wifi,
  Volume2,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';

export const StorageSettingsView: React.FC = () => {
  const {
    storageStats,
    clearOfflineStorage,
    syncWithCloud,
    syncStatus,
    playbackState,
    toggleOfflineMode,
  } = useMusic();

  const [wifiOnly, setWifiOnly] = useState(true);
  const [highQuality, setHighQuality] = useState(true);
  const [autoCacheFavorites, setAutoCacheFavorites] = useState(true);
  const [isClearing, setIsClearing] = useState(false);

  const handleClearCache = async () => {
    setIsClearing(true);
    await clearOfflineStorage();
    setTimeout(() => setIsClearing(false), 500);
  };

  const usedPercent = ((storageStats.usedMb / storageStats.totalQuotaMb) * 100).toFixed(2);

  return (
    <div className="flex-1 flex flex-col overflow-y-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header */}
      <div>
        <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5" /> Storage & Sync Engine
        </span>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">
          Device & Cloud Status
        </h1>
      </div>

      {/* Storage Gauge Card */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-purple-500/20 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Local Phone Storage</h3>
              <p className="text-[11px] text-slate-400">
                SQLite Index + /storage/emulated/0/Music
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-purple-300">
            {storageStats.usedMb} MB / 10 GB
          </span>
        </div>

        {/* Progress bar */}
        <div className="space-y-1">
          <div className="w-full h-3 rounded-full bg-slate-950 overflow-hidden p-0.5 border border-white/5">
            <div
              className="h-full rounded-full bg-gradient-to-r from-purple-600 via-pink-500 to-indigo-500 transition-all duration-500"
              style={{ width: `${Math.max(4, parseFloat(usedPercent) * 8)}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>{storageStats.downloadedSongsCount} Songs Cached</span>
            <span>{10240 - storageStats.usedMb} MB Available</span>
          </div>
        </div>

        {/* Breakdown chips */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5 text-xs">
          <div className="p-2 rounded-xl bg-slate-950/60 border border-white/5">
            <span className="text-slate-400 text-[11px] block">Offline MP3 Audio</span>
            <span className="text-white font-mono font-semibold">{storageStats.usedMb} MB</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/60 border border-white/5">
            <span className="text-slate-400 text-[11px] block">Album Art & DB Cache</span>
            <span className="text-white font-mono font-semibold">{storageStats.cacheMb} MB</span>
          </div>
        </div>

        {/* Clear cache action */}
        <button
          onClick={handleClearCache}
          disabled={isClearing || storageStats.downloadedSongsCount === 0}
          className="w-full py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
        >
          <Trash2 className="w-4 h-4" />
          <span>{isClearing ? 'Freeing Storage...' : 'Delete All Offline Cache'}</span>
        </button>
      </div>

      {/* Cloud Sync Status */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-white/10 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Supabase Cloud Sync</h3>
              <p className="text-[11px] text-slate-400">
                PostgreSQL Delta Sync & S3 Storage
              </p>
            </div>
          </div>

          <button
            onClick={syncWithCloud}
            disabled={syncStatus === 'syncing' || playbackState.isOfflineMode}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-all disabled:opacity-40"
            title="Sync Now"
          >
            <RefreshCw
              className={`w-4 h-4 ${syncStatus === 'syncing' ? 'animate-spin text-purple-400' : ''}`}
            />
          </button>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-white/5">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-purple-400" /> Cloud Database
            </span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Connected (Postgres)
            </span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-white/5">
            <span className="text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400" /> User Auth Token
            </span>
            <span className="text-slate-200 font-mono text-[11px]">dadiloveu225@gmail.com</span>
          </div>
        </div>
      </div>

      {/* Download & Network Preferences */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-white/10 shadow-lg space-y-3">
        <h3 className="text-sm font-bold text-white mb-1">Download Preferences</h3>

        <div className="space-y-3">
          <div
            onClick={() => setWifiOnly(!wifiOnly)}
            className="flex items-center justify-between p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors"
          >
            <div>
              <div className="text-xs font-semibold text-white">Download over Wi-Fi only</div>
              <div className="text-[10px] text-slate-400">Conserve cellular mobile data</div>
            </div>
            <div
              className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                wifiOnly ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  wifiOnly ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </div>
          </div>

          <div
            onClick={() => setHighQuality(!highQuality)}
            className="flex items-center justify-between p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors"
          >
            <div>
              <div className="text-xs font-semibold text-white">High Bitrate (320 kbps)</div>
              <div className="text-[10px] text-slate-400">High-fidelity studio audio downloads</div>
            </div>
            <div
              className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                highQuality ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  highQuality ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </div>
          </div>

          <div
            onClick={() => setAutoCacheFavorites(!autoCacheFavorites)}
            className="flex items-center justify-between p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors"
          >
            <div>
              <div className="text-xs font-semibold text-white">Auto-Cache Favorite Songs</div>
              <div className="text-[10px] text-slate-400">
                Immediately download loved tracks to SQLite
              </div>
            </div>
            <div
              className={`w-10 h-5 rounded-full p-0.5 transition-colors ${
                autoCacheFavorites ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  autoCacheFavorites ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
