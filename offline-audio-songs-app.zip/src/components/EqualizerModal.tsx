import React, { useState } from 'react';
import { X, Sliders, Sparkles, RotateCcw, Volume2, Music } from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import { audioEngine, EQUALIZER_PRESETS } from '../services/audioEngine';
import { EqualizerPreset } from '../types';

export const EqualizerModal: React.FC = () => {
  const { isEqualizerOpen, setIsEqualizerOpen } = useMusic();
  const [activePresetId, setActivePresetId] = useState<string>('romantic');
  const [bands, setBands] = useState(audioEngine.equalizerBands);
  const [bassBoost, setBassBoost] = useState(true);
  const [surroundSound, setSurroundSound] = useState(true);

  if (!isEqualizerOpen) return null;

  const handleBandChange = (index: number, value: number) => {
    audioEngine.setEqualizerBand(index, value);
    const updated = [...bands];
    updated[index].gain = value;
    setBands(updated);
    setActivePresetId('custom');
  };

  const handleSelectPreset = (preset: EqualizerPreset) => {
    setActivePresetId(preset.id);
    audioEngine.applyPreset(preset);
    setBands([...audioEngine.equalizerBands]);
  };

  const handleReset = () => {
    const flat = EQUALIZER_PRESETS[0];
    handleSelectPreset(flat);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-purple-500/30 rounded-3xl p-6 shadow-2xl shadow-purple-950/80 flex flex-col gap-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                5-Band High Fidelity Equalizer
              </h3>
              <p className="text-xs text-slate-400">
                DSP Audio Engine • 32-bit Floating Point
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleReset}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              title="Reset to Flat"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsEqualizerOpen(false)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Presets Chips */}
        <div>
          <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Sound Presets</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {EQUALIZER_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  activePresetId === preset.id
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40 border border-purple-400'
                    : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/5'
                }`}
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* 5 Equalizer Sliders */}
        <div className="bg-slate-950/70 rounded-2xl p-4 border border-white/5">
          <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mb-2 px-1">
            <span>+12 dB</span>
            <span>0 dB (Flat)</span>
            <span>-12 dB</span>
          </div>

          <div className="grid grid-cols-5 gap-2 h-44 items-center justify-items-center py-2">
            {bands.map((band, idx) => (
              <div key={idx} className="flex flex-col items-center h-full justify-between w-full">
                <span className="text-[11px] font-mono font-semibold text-purple-300">
                  {band.gain > 0 ? `+${band.gain}` : band.gain}
                </span>

                {/* Vertical Range Slider */}
                <div className="relative h-28 flex items-center justify-center">
                  <input
                    type="range"
                    min={-12}
                    max={12}
                    step={1}
                    value={band.gain}
                    onChange={(e) => handleBandChange(idx, parseInt(e.target.value))}
                    className="h-28 w-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500 -rotate-90 origin-center"
                    style={{ WebkitAppearance: 'slider-vertical' }}
                  />
                </div>

                <div className="text-center mt-1">
                  <span className="text-[10px] font-medium text-slate-300 block truncate">
                    {band.label.split(' ')[0]}
                  </span>
                  <span className="text-[9px] text-slate-500 block truncate">
                    {band.label.includes('Bass')
                      ? 'Bass'
                      : band.label.includes('Mid')
                      ? 'Mid'
                      : 'Treble'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* DSP Enhancements toggles */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <div
            onClick={() => setBassBoost(!bassBoost)}
            className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
              bassBoost
                ? 'bg-purple-950/40 border-purple-500/40 text-white'
                : 'bg-white/5 border-white/5 text-slate-400'
            }`}
          >
            <div>
              <div className="text-xs font-semibold">Sub-Bass Drive</div>
              <div className="text-[10px] text-slate-400">Analog warmth</div>
            </div>
            <div
              className={`w-3.5 h-3.5 rounded-full ${
                bassBoost ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50' : 'bg-slate-700'
              }`}
            />
          </div>

          <div
            onClick={() => setSurroundSound(!surroundSound)}
            className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
              surroundSound
                ? 'bg-purple-950/40 border-purple-500/40 text-white'
                : 'bg-white/5 border-white/5 text-slate-400'
            }`}
          >
            <div>
              <div className="text-xs font-semibold">3D Stereo Stage</div>
              <div className="text-[10px] text-slate-400">Spatial acoustic</div>
            </div>
            <div
              className={`w-3.5 h-3.5 rounded-full ${
                surroundSound ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50' : 'bg-slate-700'
              }`}
            />
          </div>
        </div>

        {/* Done button */}
        <button
          onClick={() => setIsEqualizerOpen(false)}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-purple-900/40 hover:opacity-95 active:scale-98 transition-all"
        >
          Apply Equalizer Setting
        </button>
      </div>
    </div>
  );
};
