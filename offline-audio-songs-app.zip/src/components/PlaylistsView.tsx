import React, { useState } from 'react';
import {
  ListMusic,
  Plus,
  Play,
  CheckCircle2,
  HardDrive,
  Sparkles,
  Music,
  Trash2,
  X,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import { Playlist } from '../types';

export const PlaylistsView: React.FC = () => {
  const {
    playlists,
    songs,
    playSong,
    createPlaylist,
    deletePlaylist,
    togglePlaylistOffline,
  } = useMusic();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [newPlaylistDesc, setNewPlaylistDesc] = useState('');
  const [selectedSongIds, setSelectedSongIds] = useState<string[]>([]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName) return;

    await createPlaylist(newPlaylistName, newPlaylistDesc, selectedSongIds);
    setNewPlaylistName('');
    setNewPlaylistDesc('');
    setSelectedSongIds([]);
    setIsCreateModalOpen(false);
  };

  const handlePlayPlaylist = (playlist: Playlist) => {
    const playlistSongs = songs.filter((s) => playlist.songIds.includes(s.id));
    if (playlistSongs.length > 0) {
      playSong(playlistSongs[0]);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Curated Playlists
          </span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            My Offline Mixes
          </h1>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600/20 text-purple-300 border border-purple-500/40 hover:bg-purple-600 hover:text-white transition-all text-xs font-semibold shadow-md active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Playlist</span>
        </button>
      </div>

      {/* Playlists Cards */}
      <div className="grid grid-cols-1 gap-3">
        {playlists.map((playlist) => {
          const count = playlist.songIds.length;
          const firstSong = songs.find((s) => playlist.songIds.includes(s.id));

          return (
            <div
              key={playlist.id}
              className="p-3.5 rounded-2xl bg-slate-900/80 border border-white/10 hover:border-purple-500/40 transition-all flex flex-col gap-3 group"
            >
              <div className="flex items-center gap-3">
                {/* Artwork */}
                <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0 border border-white/10">
                  <img
                    src={
                      playlist.coverUrl ||
                      firstSong?.artUrl ||
                      'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80'
                    }
                    alt={playlist.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <button
                    onClick={() => handlePlayPlaylist(playlist)}
                    className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Play className="w-6 h-6 text-white fill-current ml-0.5" />
                  </button>
                </div>

                {/* Details */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white tracking-tight truncate">
                      {playlist.name}
                    </h3>
                    {playlist.isOffline && (
                      <span
                        title="Auto-cached for offline listening"
                        className="text-emerald-400"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate mt-0.5">
                    {playlist.description || `${count} songs`}
                  </p>
                  <div className="flex items-center gap-2 mt-1.5 text-[11px] text-purple-300 font-mono">
                    <span>{count} Tracks</span>
                    <span>•</span>
                    <span className="text-slate-400">
                      {playlist.isOffline ? 'Offline Ready' : 'Cloud Only'}
                    </span>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex flex-col items-end gap-2 flex-shrink-0">
                  <button
                    onClick={() => handlePlayPlaylist(playlist)}
                    className="w-9 h-9 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-900/40 hover:scale-105 active:scale-95 transition-all"
                  >
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  </button>

                  <button
                    onClick={() => togglePlaylistOffline(playlist.id)}
                    className={`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${
                      playlist.isOffline
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
                    }`}
                  >
                    {playlist.isOffline ? 'Offline' : 'Make Offline'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Playlist Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-purple-500/30 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold text-white">Create Offline Playlist</h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Playlist Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Late Night Telugu Melodies"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  placeholder="e.g. Romantic road trip collection"
                  value={newPlaylistDesc}
                  onChange={(e) => setNewPlaylistDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Select Tracks */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Select Songs ({selectedSongIds.length} chosen)
                </label>
                <div className="max-h-48 overflow-y-auto space-y-1.5 p-2 rounded-xl bg-slate-950 border border-white/10">
                  {songs.map((song) => {
                    const isSelected = selectedSongIds.includes(song.id);
                    return (
                      <div
                        key={song.id}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedSongIds(selectedSongIds.filter((id) => id !== song.id));
                          } else {
                            setSelectedSongIds([...selectedSongIds, song.id]);
                          }
                        }}
                        className={`p-2 rounded-lg text-xs flex items-center justify-between cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-purple-600/30 text-white font-semibold'
                            : 'text-slate-400 hover:bg-white/5'
                        }`}
                      >
                        <span className="truncate">{song.title} - {song.artist}</span>
                        <div
                          className={`w-4 h-4 rounded border flex items-center justify-center ${
                            isSelected
                              ? 'bg-purple-600 border-purple-400 text-white'
                              : 'border-slate-600'
                          }`}
                        >
                          {isSelected && '✓'}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 text-white font-semibold text-sm hover:bg-purple-500 transition-all shadow-md shadow-purple-900/40"
              >
                Create and Sync Playlist
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
