import React, { useState } from 'react';
import {
  Search,
  Download,
  CheckCircle2,
  Cloud,
  Heart,
  Play,
  Pause,
  Plus,
  HardDrive,
  Sparkles,
  Plane,
  FolderDown,
  Layers,
  Music,
  Trash2,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import { Song } from '../types';

export const LibraryView: React.FC = () => {
  const {
    songs,
    currentSong,
    playbackState,
    playSong,
    togglePlayPause,
    downloadSong,
    deleteDownload,
    downloadAllOffline,
    downloadProgress,
    toggleFavorite,
    setIsUploadModalOpen,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    storageStats,
  } = useMusic();

  const categories = [
    'All',
    'Offline Saved',
    'Telugu Romance',
    'Favorites',
    'Acoustic',
    'Hi Nanna',
    'Sid Sriram',
  ];

  // Filter songs based on search query and category
  const filteredSongs = songs.filter((song) => {
    const matchesSearch =
      song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      song.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (song.movie && song.movie.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (song.genre && song.genre.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (selectedCategory === 'Offline Saved') return song.isDownloaded;
    if (selectedCategory === 'Favorites') return song.isFavorite;
    if (selectedCategory === 'Telugu Romance')
      return (
        song.genre?.includes('Romance') ||
        song.genre?.includes('Melody') ||
        song.movie?.includes('Sita')
      );
    if (selectedCategory === 'Acoustic')
      return song.genre?.includes('Acoustic') || song.genre?.includes('Folk');
    if (selectedCategory === 'Hi Nanna')
      return song.movie?.includes('Hi Nanna') || song.title.includes('Gaali');
    if (selectedCategory === 'Sid Sriram')
      return song.artist.includes('Sid Sriram');

    return true;
  });

  const undownloadedCount = songs.filter((s) => !s.isDownloaded).length;

  return (
    <div className="flex-1 flex flex-col overflow-y-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header Profile & Quick Action */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Self-Purpose Offline Audio
          </span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Romantic Melodies
          </h1>
        </div>

        <button
          onClick={() => setIsUploadModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600/20 text-purple-300 border border-purple-500/40 hover:bg-purple-600 hover:text-white transition-all text-xs font-semibold shadow-md active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add MP3</span>
        </button>
      </div>

      {/* Offline Status / Download Banner */}
      {playbackState.isOfflineMode ? (
        <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 flex items-center justify-between gap-3 text-amber-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 flex-shrink-0">
              <Plane className="w-4 h-4" />
            </div>
            <div className="text-xs min-w-0">
              <span className="font-bold block">Airplane Mode Active</span>
              <span className="text-[11px] text-amber-300/80 truncate block">
                Reading audio files directly from local phone disk (SQLite)
              </span>
            </div>
          </div>
        </div>
      ) : undownloadedCount > 0 ? (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 to-indigo-950/60 border border-purple-500/30 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 flex-shrink-0">
              <FolderDown className="w-4 h-4" />
            </div>
            <div className="text-xs min-w-0">
              <span className="font-bold text-white block">
                {storageStats.downloadedSongsCount} of {storageStats.totalSongsCount} songs saved offline
              </span>
              <span className="text-[11px] text-slate-400 truncate block">
                {storageStats.usedMb} MB used in local storage
              </span>
            </div>
          </div>

          <button
            onClick={downloadAllOffline}
            className="px-3 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-500 active:scale-95 transition-all flex-shrink-0 shadow-sm"
          >
            Download All
          </button>
        </div>
      ) : (
        <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/20 flex items-center justify-between text-xs text-emerald-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-medium">All songs are synchronized & saved offline</span>
          </div>
          <span className="font-mono text-[11px] opacity-80">{storageStats.usedMb} MB</span>
        </div>
      )}

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search by song, movie, artist or genre..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-500 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        )}
      </div>

      {/* Category Filter Chips */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar select-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40 border border-purple-400'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Song List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1 text-xs text-slate-400">
          <span>{filteredSongs.length} Tracks Available</span>
          <span className="flex items-center gap-1 font-mono text-[11px]">
            <HardDrive className="w-3 h-3 text-purple-400" /> SQLite Sync
          </span>
        </div>

        {filteredSongs.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-3">
            <Music className="w-12 h-12 mx-auto text-slate-600" />
            <p className="text-sm">No songs match your search or filter.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="text-xs text-purple-400 underline"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          filteredSongs.map((song, index) => {
            const isCurrent = currentSong?.id === song.id;
            const isDownloading = downloadProgress[song.id] !== undefined;
            const pct = downloadProgress[song.id] || 0;

            return (
              <div
                key={song.id}
                onClick={() => {
                  if (isCurrent) {
                    togglePlayPause();
                  } else {
                    playSong(song);
                  }
                }}
                className={`group p-2.5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 ${
                  isCurrent
                    ? 'bg-purple-950/30 border-purple-500/40 shadow-md shadow-purple-950/50'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-white/5 hover:border-white/10'
                }`}
              >
                {/* Track Artwork & Index */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 bg-slate-800 border border-white/10">
                    <img
                      src={song.artUrl}
                      alt={song.title}
                      className="w-full h-full object-cover"
                    />

                    {/* Play/Pause Overlay */}
                    <div
                      className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
                        isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                      }`}
                    >
                      {isCurrent && playbackState.isPlaying ? (
                        <Pause className="w-5 h-5 text-white fill-current" />
                      ) : (
                        <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                      )}
                    </div>
                  </div>

                  {/* Title & Metadata */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3
                        className={`text-sm font-semibold truncate ${
                          isCurrent ? 'text-purple-300' : 'text-white'
                        }`}
                      >
                        {song.title}
                      </h3>
                      {song.isDownloaded ? (
                        <span title="Stored locally" className="text-emerald-400 flex-shrink-0">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </span>
                      ) : (
                        <span title="Cloud Stream" className="text-sky-400 flex-shrink-0">
                          <Cloud className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 truncate mt-0.5">
                      <span className="truncate">{song.artist}</span>
                      <span>•</span>
                      <span className="text-purple-400/90 font-medium truncate">
                        {song.movie || song.genre}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right side: Duration, Download button, and Favorite */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  {/* Download status / button */}
                  {song.isDownloaded ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteDownload(song.id);
                      }}
                      title="Stored in SQLite & Local Disk (Click to remove offline copy)"
                      className="p-1.5 rounded-lg text-emerald-400 hover:text-rose-400 hover:bg-white/5 transition-colors text-[11px] font-mono flex items-center gap-1"
                    >
                      <span>{song.fileSizeMb}MB</span>
                    </button>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadSong(song);
                      }}
                      disabled={isDownloading}
                      title="Download to Phone Storage"
                      className="p-2 rounded-xl bg-purple-600/20 text-purple-300 hover:bg-purple-600 hover:text-white transition-all active:scale-90"
                    >
                      {isDownloading ? (
                        <span className="text-[10px] font-mono font-bold text-purple-300">
                          {pct}%
                        </span>
                      ) : (
                        <Download className="w-4 h-4" />
                      )}
                    </button>
                  )}

                  {/* Favorite Heart */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(song.id);
                    }}
                    className={`p-2 rounded-lg transition-transform active:scale-90 ${
                      song.isFavorite
                        ? 'text-pink-500'
                        : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${song.isFavorite ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
