import React, { useState, useRef } from 'react';
import { X, Upload, Music, Image as ImageIcon, Sparkles, CheckCircle2, HardDrive } from 'lucide-react';
import { useMusic } from '../context/MusicContext';

export const UploadModal: React.FC = () => {
  const { isUploadModalOpen, setIsUploadModalOpen, uploadNewSong } = useMusic();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [movie, setMovie] = useState('');
  const [genre, setGenre] = useState('Romantic Melody');
  const [artUrl, setArtUrl] = useState(
    'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isUploadModalOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);

      // Auto populate clean title from filename
      const cleanName = selected.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
      if (!title) {
        setTitle(cleanName);
      }
      if (!artist) {
        setArtist('Self Purpose / Dadiloveu');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    setIsSubmitting(true);
    try {
      await uploadNewSong({
        file: file || undefined,
        title,
        artist: artist || 'Local Artist',
        movie: movie || 'Telugu Hits',
        genre,
        artUrl,
      });

      // Reset and close
      setFile(null);
      setTitle('');
      setArtist('');
      setMovie('');
      setIsUploadModalOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const sampleCovers = [
    'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=600&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-purple-500/30 rounded-3xl p-6 shadow-2xl shadow-purple-950/80 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Add Songs to Local Storage
              </h3>
              <p className="text-xs text-slate-400">
                Auto-saved to Phone SQLite & IndexedDB
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsUploadModalOpen(false)}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* File Picker Drag & Drop */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-purple-500/40 hover:border-purple-500 bg-purple-950/20 rounded-2xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 group"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="p-3 rounded-full bg-purple-600/20 text-purple-400 group-hover:scale-110 transition-transform">
              <Music className="w-6 h-6" />
            </div>
            {file ? (
              <div>
                <span className="text-sm font-semibold text-emerald-400 flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> {file.name}
                </span>
                <span className="text-xs text-slate-400">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB • Ready for local sync
                </span>
              </div>
            ) : (
              <div>
                <span className="text-sm font-medium text-slate-200 block">
                  Click or Drop audio file (.mp3, .m4a, .wav)
                </span>
                <span className="text-xs text-slate-400 block">
                  Supports local phone storage & background sync
                </span>
              </div>
            )}
          </div>

          {/* Song Metadata Fields */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Song Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Oh Sita Hey Rama / Gaali Chirugaali"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500 transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Artist(s)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Sid Sriram, Hesham"
                  value={artist}
                  onChange={(e) => setArtist(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Movie / Album
                </label>
                <input
                  type="text"
                  placeholder="e.g. Sita Ramam / Hi Nanna"
                  value={movie}
                  onChange={(e) => setMovie(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Genre / Vibe
              </label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500 transition-colors"
              >
                <option value="Romantic Melody">Romantic Melody (Telugu)</option>
                <option value="Acoustic Love">Acoustic Love</option>
                <option value="Romantic Duet">Romantic Duet</option>
                <option value="Lo-Fi Love">Lo-Fi Chill</option>
                <option value="Cinematic Strings">Cinematic Strings</option>
                <option value="Classical Fusion">Classical Fusion</option>
              </select>
            </div>

            {/* Cover Art selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
                <span>Album Artwork</span>
                <span className="text-[11px] text-purple-400">Select Preset</span>
              </label>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {sampleCovers.map((img, i) => (
                  <img
                    key={i}
                    src={img}
                    alt={`Cover ${i}`}
                    onClick={() => setArtUrl(img)}
                    className={`w-12 h-12 rounded-lg object-cover cursor-pointer transition-all border-2 flex-shrink-0 ${
                      artUrl === img
                        ? 'border-purple-500 scale-105 shadow-md shadow-purple-500/50'
                        : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isSubmitting || !title}
            className="w-full py-3.5 mt-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-purple-900/40 hover:opacity-95 active:scale-98 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span>Saving to Phone Storage...</span>
            ) : (
              <>
                <HardDrive className="w-4 h-4" />
                <span>Save to Offline Library</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
