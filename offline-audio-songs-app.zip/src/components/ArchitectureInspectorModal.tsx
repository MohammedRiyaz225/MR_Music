import React, { useState } from 'react';
import {
  Layers,
  Smartphone,
  Database,
  Cloud,
  HardDrive,
  Cpu,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Play,
  RefreshCw,
  Code2,
  FileCode,
} from 'lucide-react';

export const ArchitectureInspectorModal: React.FC = () => {
  const [activeLayer, setActiveLayer] = useState<number>(0);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simStep, setSimStep] = useState<number>(-1);

  const architectureLayers = [
    {
      title: '1. Mobile Client (Frontend)',
      tech: 'Flutter / React Native UI',
      icon: Smartphone,
      color: 'from-purple-500 to-indigo-500',
      description:
        'Native UI rendering with JustAudio + AudioService for persistent background playback with lockscreen controls.',
      components: [
        'Mini-Player & Full-Screen Visualizer',
        'State Management (Provider / Bloc)',
        'MetadataGod ID3 Tag Reader',
        'Offline-First Navigation Router',
      ],
      codeSnippet: `// Audio Handler Service
class AudioPlayerHandler extends BaseAudioHandler {
  final _player = AudioPlayer();
  
  @override
  Future<void> play() => _player.play();
  
  @override
  Future<void> pause() => _player.pause();
}`,
    },
    {
      title: '2. Local SQLite & Storage Cache',
      tech: 'SQLite (sqflite) + Local Disk',
      icon: HardDrive,
      color: 'from-emerald-500 to-teal-500',
      description:
        'Primary offline source of truth. Stores song metadata, playlists, and raw .mp3 binary files on the phone filesystem.',
      components: [
        'Local path: /storage/emulated/0/Music/*.mp3',
        'Fast indexed SQL queries (< 2ms)',
        'Zero-network latency playback',
        'Storage quota auto-cleanup',
      ],
      codeSnippet: `CREATE TABLE songs (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  artist TEXT,
  file_path TEXT,
  is_downloaded INTEGER DEFAULT 0,
  updated_at TIMESTAMP
);`,
    },
    {
      title: '3. Sync & Download Engine',
      tech: 'Dio + Background WorkManager',
      icon: RefreshCw,
      color: 'from-amber-500 to-orange-500',
      description:
        'Handles timestamp-based Delta Sync. Downloads files in background chunks with resume capability and progress notifications.',
      components: [
        'Delta Sync: fetch records WHERE updated_at > lastSync',
        'Chunked streaming download with Dio',
        'Network state listener (Wi-Fi vs Cellular)',
        'Storage verification hash checks',
      ],
      codeSnippet: `Future<void> syncSongs() async {
  final lastSync = await getLocalSyncTimestamp();
  final updates = await supabase
      .from('songs')
      .select()
      .gt('updated_at', lastSync);
  await dbHelper.batchUpsert(updates);
}`,
    },
    {
      title: '4. Cloud Backend & Database',
      tech: 'Supabase (PostgreSQL + S3 Storage)',
      icon: Cloud,
      color: 'from-sky-500 to-blue-500',
      description:
        'Cloud repository hosting high-bitrate Telugu romantic tracks, ID3 tags, and user playlists with JWT authentication.',
      components: [
        'PostgreSQL with Row Level Security (RLS)',
        'S3 Audio Bucket (320kbps MP3s)',
        'Realtime Change Subscriptions',
        'Auto-backup & cloud restore',
      ],
      codeSnippet: `-- Supabase Row Level Security
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public songs are viewable by owner"
  ON songs FOR ALL
  USING (auth.uid() = user_id);`,
    },
  ];

  const runSimulation = async () => {
    if (isSimulating) return;
    setIsSimulating(true);
    for (let i = 0; i < 4; i++) {
      setSimStep(i);
      setActiveLayer(i);
      await new Promise((r) => setTimeout(r, 900));
    }
    setIsSimulating(false);
    setSimStep(-1);
  };

  const selected = architectureLayers[activeLayer];
  const Icon = selected.icon;

  return (
    <div className="flex-1 flex flex-col overflow-y-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Project Architecture
          </span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Offline-First System Design
          </h1>
        </div>

        <button
          onClick={runSimulation}
          disabled={isSimulating}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600 text-white hover:bg-purple-500 transition-all text-xs font-semibold shadow-md active:scale-95 disabled:opacity-50"
        >
          <Play className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : 'fill-current'}`} />
          <span>{isSimulating ? 'Simulating...' : 'Simulate Data Flow'}</span>
        </button>
      </div>

      {/* Architecture Interactive Flow Map */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {architectureLayers.map((layer, index) => {
          const LayerIcon = layer.icon;
          const isActive = activeLayer === index;
          const isCurrentStep = simStep === index;

          return (
            <button
              key={index}
              onClick={() => setActiveLayer(index)}
              className={`p-3 rounded-2xl border text-left transition-all relative overflow-hidden ${
                isActive
                  ? 'bg-slate-900 border-purple-500/80 shadow-lg shadow-purple-950/60'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/15'
              } ${isCurrentStep ? 'ring-2 ring-purple-400 animate-pulse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${layer.color} text-white flex items-center justify-center mb-2 shadow-sm`}
              >
                <LayerIcon className="w-4 h-4" />
              </div>
              <div className="text-[11px] font-mono text-purple-400 font-semibold truncate">
                Layer 0{index + 1}
              </div>
              <div className="text-xs font-bold text-white truncate">{layer.tech.split('/')[0]}</div>
            </button>
          );
        })}
      </div>

      {/* Detailed Layer Card */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-purple-500/30 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-2xl bg-gradient-to-tr ${selected.color} text-white shadow-md`}
            >
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">{selected.title}</h3>
              <p className="text-xs text-purple-300 font-mono">{selected.tech}</p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-semibold text-slate-300">
            Active Architecture
          </span>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed">{selected.description}</p>

        {/* Components Checklist */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Key Modules & Responsibilities
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {selected.components.map((comp, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-950 border border-white/5 flex items-center gap-2 text-xs text-slate-200"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>{comp}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Code Implementation Preview */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-mono flex items-center gap-1">
              <FileCode className="w-3.5 h-3.5 text-purple-400" /> Implementation Blueprint
            </span>
            <span className="text-[10px] text-slate-500">Offline-First Design</span>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-white/10 overflow-x-auto">
            <pre className="text-xs font-mono text-purple-200 leading-relaxed">
              <code>{selected.codeSnippet}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
