import React, { useState, useEffect } from 'react';
import { Wifi, Plane, Battery, ShieldCheck, Activity } from 'lucide-react';
import { useMusic } from '../context/MusicContext';

export const MobileStatusBar: React.FC = () => {
  const { playbackState, toggleOfflineMode, currentSong, setIsFullPlayerOpen } = useMusic();
  const [timeString, setTimeString] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-slate-950/90 backdrop-blur-md text-slate-300 text-xs px-5 pt-3 pb-2 flex items-center justify-between select-none z-30 border-b border-white/5">
      {/* Left Time */}
      <div className="font-semibold text-sm tracking-tight text-white flex items-center gap-1.5">
        <span>{timeString || '9:41 AM'}</span>
      </div>

      {/* Dynamic Island pill */}
      <button
        onClick={() => currentSong && setIsFullPlayerOpen(true)}
        className={`h-6 px-3 rounded-full transition-all duration-300 flex items-center gap-2 cursor-pointer ${
          playbackState.isPlaying
            ? 'bg-slate-900 border border-purple-500/40 shadow-sm shadow-purple-500/20'
            : 'bg-slate-900/80 border border-white/10'
        }`}
      >
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        {currentSong ? (
          <div className="flex items-center gap-1.5 max-w-[130px] overflow-hidden">
            <Activity className={`w-3 h-3 text-purple-400 ${playbackState.isPlaying ? 'animate-pulse' : ''}`} />
            <span className="text-[10px] font-medium text-slate-200 truncate">
              {currentSong.title}
            </span>
          </div>
        ) : (
          <span className="text-[10px] font-medium text-slate-400">AuraSound Engine</span>
        )}
      </button>

      {/* Right System Icons & Airplane Toggle */}
      <div className="flex items-center gap-2.5">
        {/* Airplane Mode Toggle Button */}
        <button
          onClick={toggleOfflineMode}
          title={
            playbackState.isOfflineMode
              ? 'Offline (Airplane Mode active) - playing from Local SQLite & Storage'
              : 'Online (Connected to Cloud Backend)'
          }
          className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium transition-all ${
            playbackState.isOfflineMode
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
              : 'hover:bg-white/10 text-slate-400'
          }`}
        >
          {playbackState.isOfflineMode ? (
            <>
              <Plane className="w-3 h-3 text-amber-400 rotate-45" />
              <span className="hidden sm:inline">Offline</span>
            </>
          ) : (
            <>
              <Wifi className="w-3 h-3 text-emerald-400" />
              <span className="hidden sm:inline text-slate-300">5G</span>
            </>
          )}
        </button>

        <div className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-purple-400" title="JWT Auth Active" />
          <div className="flex items-center gap-0.5">
            <span className="text-[10px] font-mono text-slate-400">88%</span>
            <Battery className="w-4 h-4 text-slate-200" />
          </div>
        </div>
      </div>
    </div>
  );
};
