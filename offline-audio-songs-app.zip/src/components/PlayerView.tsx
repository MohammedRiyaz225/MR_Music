import React, { useState } from 'react';
import {
  ChevronDown,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Download,
  CheckCircle2,
  HardDrive,
  Sliders,
  Volume2,
  VolumeX,
  FileText,
  Music,
  Share2,
  Sparkles,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import { AudioVisualizer } from './AudioVisualizer';

export const PlayerView: React.FC = () => {
  const {
    currentSong,
    playbackState,
    isFullPlayerOpen,
    setIsFullPlayerOpen,
    setIsEqualizerOpen,
    togglePlayPause,
    skipNext,
    skipPrevious,
    seekTo,
    setVolume,
    toggleMute,
    toggleShuffle,
    cycleRepeatMode,
    setPlaybackRate,
    toggleFavorite,
    downloadSong,
    downloadProgress,
  } = useMusic();

  const [showLyrics, setShowLyrics] = useState(false);
  const [speedMenuOpen, setSpeedMenuOpen] = useState(false);

  if (!isFullPlayerOpen || !currentSong) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const isDownloading = downloadProgress[currentSong.id] !== undefined;
  const downloadPct = downloadProgress[currentSong.id] || 0;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-300">
      {/* Background blurred glow of album art */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-25 blur-3xl scale-125 pointer-events-none transition-all duration-700"
        style={{ backgroundImage: `url(${currentSong.artUrl})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/90 to-slate-950 pointer-events-none" />

      {/* Top Navigation Bar */}
      <div className="relative z-10 px-6 pt-4 pb-2 flex items-center justify-between">
        <button
          onClick={() => setIsFullPlayerOpen(false)}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-all active:scale-90"
        >
          <ChevronDown className="w-6 h-6" />
        </button>

        <div className="text-center flex flex-col items-center">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-purple-400">
            {currentSong.movie || 'Romantic Hits'}
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                currentSong.isDownloaded ? 'bg-emerald-400' : 'bg-sky-400'
              }`}
            />
            <span className="text-xs text-slate-300 font-medium">
              {currentSong.isDownloaded ? 'Offline (Local Disk)' : 'Online Cloud Stream'}
            </span>
          </div>
        </div>

        <button
          onClick={() => setIsEqualizerOpen(true)}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-purple-400 transition-all active:scale-90"
          title="Open Equalizer"
        >
          <Sliders className="w-5 h-5" />
        </button>
      </div>

      {/* Main Content: Album Art or Lyrics View */}
      <div className="relative z-10 flex-1 px-8 py-4 flex flex-col items-center justify-center min-h-0">
        {showLyrics ? (
          <div className="w-full max-w-sm h-72 sm:h-80 bg-slate-900/80 backdrop-blur-xl rounded-3xl p-6 border border-purple-500/20 shadow-2xl flex flex-col overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-4 h-4" /> Telugu Lyrics & Meaning
              </span>
              <button
                onClick={() => setShowLyrics(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Show Art
              </button>
            </div>
            <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1 text-center">
              {currentSong.lyrics && currentSong.lyrics.length > 0 ? (
                currentSong.lyrics.map((line, idx) => (
                  <p
                    key={idx}
                    className={`text-sm font-medium transition-all ${
                      idx === 1
                        ? 'text-purple-300 text-base font-bold scale-105'
                        : 'text-slate-300'
                    }`}
                  >
                    {line}
                  </p>
                ))
              ) : (
                <div className="py-12 text-slate-400 text-sm">
                  No synced lyrics available for this track.
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-auto flex items-center justify-center">
            {/* Glowing outer ambient aura */}
            <div
              className={`absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600/30 to-pink-600/30 blur-2xl transition-all duration-700 ${
                playbackState.isPlaying ? 'scale-110 opacity-100' : 'scale-95 opacity-40'
              }`}
            />

            {/* Vinyl record & Art container */}
            <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl shadow-purple-950/60 border border-white/15 bg-slate-900 group">
              <img
                src={currentSong.artUrl}
                alt={currentSong.title}
                className={`w-full h-full object-cover transition-transform duration-700 ${
                  playbackState.isPlaying ? 'scale-105' : 'scale-100'
                }`}
              />

              {/* Offline Badge overlay */}
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full glass-pill text-[11px] font-semibold flex items-center gap-1.5 text-white shadow-md">
                {currentSong.isDownloaded ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Saved Offline</span>
                  </>
                ) : (
                  <>
                    <HardDrive className="w-3.5 h-3.5 text-sky-400" />
                    <span>{currentSong.fileSizeMb} MB</span>
                  </>
                )}
              </div>

              {/* Bitrate badge */}
              <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-slate-950/80 border border-white/10 text-[10px] font-mono text-purple-300">
                {currentSong.bitRate || '320kbps HD'}
              </div>
            </div>
          </div>
        )}

        {/* Audio Visualizer Canvas */}
        <div className="w-full max-w-sm px-2 mt-2 mb-1">
          <AudioVisualizer isPlaying={playbackState.isPlaying} barsCount={32} height={36} color="#c084fc" />
        </div>
      </div>

      {/* Bottom Track Meta & Interactive Controls */}
      <div className="relative z-10 px-8 pb-8 flex flex-col gap-4">
        {/* Title, Artist, and Favorite */}
        <div className="flex items-center justify-between">
          <div className="min-w-0 flex-1 pr-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight truncate">
              {currentSong.title}
            </h2>
            <p className="text-sm text-slate-400 truncate mt-0.5">
              {currentSong.artist} • {currentSong.genre || 'Telugu'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleFavorite(currentSong.id)}
              className={`p-2.5 rounded-full transition-all active:scale-90 ${
                currentSong.isFavorite
                  ? 'text-pink-500 bg-pink-500/10'
                  : 'text-slate-400 hover:text-white bg-white/5'
              }`}
            >
              <Heart className={`w-5 h-5 ${currentSong.isFavorite ? 'fill-current' : ''}`} />
            </button>

            {/* Offline download trigger */}
            {!currentSong.isDownloaded ? (
              <button
                onClick={() => downloadSong(currentSong)}
                disabled={isDownloading}
                className="p-2.5 rounded-full bg-purple-600/20 text-purple-300 border border-purple-500/30 hover:bg-purple-600/40 transition-all active:scale-90 flex items-center gap-1"
                title="Download for offline playback"
              >
                {isDownloading ? (
                  <span className="text-[10px] font-mono font-bold">{downloadPct}%</span>
                ) : (
                  <Download className="w-5 h-5" />
                )}
              </button>
            ) : null}
          </div>
        </div>

        {/* Scrubbable Seek Bar */}
        <div className="w-full space-y-1.5">
          <input
            type="range"
            min={0}
            max={playbackState.duration || 240}
            value={playbackState.currentTime}
            onChange={(e) => seekTo(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500 hover:accent-pink-400 transition-all"
          />
          <div className="flex justify-between text-xs font-mono text-slate-400">
            <span>{formatTime(playbackState.currentTime)}</span>
            <span>{formatTime(playbackState.duration)}</span>
          </div>
        </div>

        {/* Main Controls Row: Shuffle, Prev, Play/Pause, Next, Repeat */}
        <div className="flex items-center justify-between px-2 pt-1">
          <button
            onClick={toggleShuffle}
            className={`p-2 rounded-full transition-colors active:scale-90 ${
              playbackState.isShuffled ? 'text-purple-400' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Shuffle"
          >
            <Shuffle className="w-5 h-5" />
          </button>

          <button
            onClick={skipPrevious}
            className="p-3 text-slate-200 hover:text-white rounded-full transition-transform active:scale-90"
            title="Previous Track"
          >
            <SkipBack className="w-7 h-7 fill-current" />
          </button>

          {/* Glowing Play/Pause button */}
          <button
            onClick={togglePlayPause}
            className="w-16 h-16 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-500 text-white flex items-center justify-center shadow-xl shadow-purple-900/50 hover:scale-105 active:scale-95 transition-all"
          >
            {playbackState.isPlaying ? (
              <Pause className="w-7 h-7 fill-current" />
            ) : (
              <Play className="w-7 h-7 fill-current ml-1" />
            )}
          </button>

          <button
            onClick={skipNext}
            className="p-3 text-slate-200 hover:text-white rounded-full transition-transform active:scale-90"
            title="Next Track"
          >
            <SkipForward className="w-7 h-7 fill-current" />
          </button>

          <button
            onClick={cycleRepeatMode}
            className={`p-2 rounded-full transition-colors active:scale-90 ${
              playbackState.repeatMode !== 'off'
                ? 'text-purple-400'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title={`Repeat: ${playbackState.repeatMode}`}
          >
            {playbackState.repeatMode === 'one' ? (
              <Repeat1 className="w-5 h-5" />
            ) : (
              <Repeat className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Secondary row: Volume & Lyrics / Speed controls */}
        <div className="pt-2 flex items-center justify-between border-t border-white/5 px-2">
          {/* Volume slider */}
          <div className="flex items-center gap-2 flex-1 max-w-[140px]">
            <button
              onClick={toggleMute}
              className="text-slate-400 hover:text-white transition-colors"
            >
              {playbackState.isMuted || playbackState.volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={playbackState.isMuted ? 0 : playbackState.volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
          </div>

          {/* Quick Action Pills */}
          <div className="flex items-center gap-2">
            {/* Speed selector */}
            <div className="relative">
              <button
                onClick={() => setSpeedMenuOpen(!speedMenuOpen)}
                className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-[11px] font-mono text-slate-300 border border-white/10 transition-colors"
              >
                {playbackState.playbackRate}x
              </button>
              {speedMenuOpen && (
                <div className="absolute bottom-full mb-2 right-0 bg-slate-900 border border-white/15 rounded-xl shadow-xl p-1 z-30 flex flex-col gap-1 min-w-[70px]">
                  {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        setPlaybackRate(rate);
                        setSpeedMenuOpen(false);
                      }}
                      className={`px-2 py-1 text-xs font-mono rounded text-center transition-colors ${
                        playbackState.playbackRate === rate
                          ? 'bg-purple-600 text-white font-bold'
                          : 'text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Lyrics toggle */}
            <button
              onClick={() => setShowLyrics(!showLyrics)}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-all flex items-center gap-1.5 ${
                showLyrics
                  ? 'bg-purple-600 text-white border-purple-500'
                  : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Lyrics</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
