import { Song, Playlist } from '../types';

export const INITIAL_SONGS: Song[] = [
  {
    id: 'sita-ramam-1',
    title: 'Oh Sita Hey Rama',
    artist: 'S.P. Charan, Ramya Behara',
    movie: 'Sita Ramam',
    album: 'Sita Ramam (Telugu)',
    duration: 254,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=melody-of-nature-110624.mp3',
    artUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    isDownloaded: true,
    downloadedAt: '2026-08-25T14:32:00Z',
    fileSizeMb: 8.4,
    localPath: '/storage/emulated/0/Music/Oh_Sita_Hey_Rama.mp3',
    isFavorite: true,
    genre: 'Romantic Melody',
    bitRate: '320 kbps',
    playsCount: 42,
    synthTheme: 'piano_ballad',
    lyrics: [
      'Oh Sita... Hey Rama...',
      'Etu choosinaa nee roopame...',
      'Manasuloni mounam virisene...',
      'Prathi janmaloo thodu nene...',
      'Gundellone ninnu daachukunna...',
      'Kanneellanni navvulayyene...'
    ]
  },
  {
    id: 'hi-nanna-2',
    title: 'Gaali Chirugaali',
    artist: 'Kapil Kapilan, Hesham Abdul Wahab',
    movie: 'Hi Nanna',
    album: 'Hi Nanna (Original Soundtrack)',
    duration: 218,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=acoustic-guitars-ambient-uplifting-10905.mp3',
    artUrl: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600&auto=format&fit=crop&q=80',
    isDownloaded: true,
    downloadedAt: '2026-08-25T16:10:00Z',
    fileSizeMb: 6.9,
    localPath: '/storage/emulated/0/Music/Gaali_Chirugaali.mp3',
    isFavorite: true,
    genre: 'Acoustic Love',
    bitRate: '320 kbps',
    playsCount: 29,
    synthTheme: 'romantic_acoustic',
    lyrics: [
      'Gaali chirugaali veeche vela...',
      'Nee cheli choope nannu thaakene...',
      'Premalona thelipothunna hrudayam...',
      'Kanti paapala katha idheley...',
      'Vennelanthaa kurise chotey manam...'
    ]
  },
  {
    id: 'kushi-3',
    title: 'Aradhya',
    artist: 'Sid Sriram, Chinmayi Sripaada',
    movie: 'Kushi',
    album: 'Kushi (Telugu)',
    duration: 275,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/10/14/audio_9939f792cb.mp3?filename=lofi-study-112191.mp3',
    artUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    isDownloaded: false,
    fileSizeMb: 9.1,
    isFavorite: false,
    genre: 'Romantic Duet',
    bitRate: '320 kbps',
    playsCount: 15,
    synthTheme: 'rnb_slow',
    lyrics: [
      'Nuvve naa Aaradhya...',
      'Naa loni pranam nuvva...',
      'Cheliya nee kougitlo karige kshanam...',
      'Kalisaam kaalam aage vela...',
      'Vandhala maatalu enduku chepu...'
    ]
  },
  {
    id: 'geetha-govindam-4',
    title: 'Inkem Inkem Inkem Kaavaale',
    artist: 'Sid Sriram, Gopi Sundar',
    movie: 'Geetha Govindam',
    album: 'Geetha Govindam',
    duration: 268,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2021/08/04/audio_bb630cc098.mp3?filename=flute-traditional-melody-7848.mp3',
    artUrl: 'https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=600&auto=format&fit=crop&q=80',
    isDownloaded: true,
    downloadedAt: '2026-08-24T10:00:00Z',
    fileSizeMb: 8.8,
    localPath: '/storage/emulated/0/Music/Inkem_Inkem_Kaavaale.mp3',
    isFavorite: true,
    genre: 'Folk Romance',
    bitRate: '320 kbps',
    playsCount: 65,
    synthTheme: 'romantic_acoustic',
    lyrics: [
      'Inkem inkem inkem kaavaale...',
      'Chaaley idi chaaley...',
      'Nee sneham dhorikithey chaaley...',
      'Gunde thalupu theesi choosuko...',
      'Prathi nimisham neeve oopiri...'
    ]
  },
  {
    id: 'radhe-shyam-5',
    title: 'Nagumomu Thaarale',
    artist: 'Sid Sriram, Justin Prabhakaran',
    movie: 'Radhe Shyam',
    album: 'Radhe Shyam',
    duration: 290,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=romantic-piano-10815.mp3',
    artUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80',
    isDownloaded: false,
    fileSizeMb: 9.6,
    isFavorite: false,
    genre: 'Cinematic Romance',
    bitRate: '320 kbps',
    playsCount: 19,
    synthTheme: 'cinematic_strings',
    lyrics: [
      'Nagumomu thaarale taaralaina vela...',
      'Preme o varamaaye...',
      'Gundelo gudu katti ninnu nannu chere...',
      'Theeram chere aala laa...'
    ]
  },
  {
    id: 'jersey-6',
    title: 'Adhento Gaani Vunnapaatuga',
    artist: 'Anirudh Ravichander',
    movie: 'Jersey',
    album: 'Jersey (Original Motion Picture)',
    duration: 236,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/02/07/audio_d1e89cf24f.mp3?filename=soft-rain-ambient-111154.mp3',
    artUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    isDownloaded: false,
    fileSizeMb: 7.8,
    isFavorite: true,
    genre: 'Indie Pop Romance',
    bitRate: '320 kbps',
    playsCount: 51,
    synthTheme: 'lofi_chill',
    lyrics: [
      'Adhento gaani vunnapaatuga...',
      'Madhey munigipoye maatalenno...',
      'Choopulevo guchuthunnaye...',
      'Nee vente thodu unte chaalu...'
    ]
  },
  {
    id: 'uppena-7',
    title: 'Nee Kannu Neeli Samudram',
    artist: 'Javed Ali, Srikanth Chandra, DSP',
    movie: 'Uppena',
    album: 'Uppena',
    duration: 312,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/03/10/audio_510b65f3f4.mp3?filename=serenade-melody-10777.mp3',
    artUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80',
    isDownloaded: true,
    downloadedAt: '2026-08-23T19:45:00Z',
    fileSizeMb: 10.2,
    localPath: '/storage/emulated/0/Music/Nee_Kannu_Neeli_Samudram.mp3',
    isFavorite: true,
    genre: 'Qawwali Romance',
    bitRate: '320 kbps',
    playsCount: 78,
    synthTheme: 'piano_ballad',
    lyrics: [
      'Nee kannu neeli samudram...',
      'Naa manasu andhulo chepa chepala...',
      'Eedhuthundhe nee kanti choopu vela...',
      'Mounam lona maatalanni prema ga maare...'
    ]
  },
  {
    id: 'chaleya-8',
    title: 'Chaleya (Telugu Version)',
    artist: 'Arijit Singh, Shilpa Rao, Anirudh',
    movie: 'Jawan',
    album: 'Jawan',
    duration: 200,
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/01/26/audio_d0c6ff1101.mp3?filename=sweet-romance-10928.mp3',
    artUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&auto=format&fit=crop&q=80',
    isDownloaded: false,
    fileSizeMb: 6.5,
    isFavorite: false,
    genre: 'Dance Romance',
    bitRate: '320 kbps',
    playsCount: 38,
    synthTheme: 'rnb_slow',
    lyrics: [
      'Chaleya premaloki cherey...',
      'Nee navvulone bandhinchey...',
      'Nanne nenu marichithine...'
    ]
  }
];

export const INITIAL_PLAYLISTS: Playlist[] = [
  {
    id: 'pl-1',
    name: 'Midnight Romantic Hits',
    description: 'Soulful Telugu acoustic love songs for peaceful nights',
    coverUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&auto=format&fit=crop&q=80',
    songIds: ['sita-ramam-1', 'hi-nanna-2', 'geetha-govindam-4', 'uppena-7'],
    isOffline: true,
    createdAt: '2026-08-20T12:00:00Z'
  },
  {
    id: 'pl-2',
    name: 'Sid Sriram Melodies',
    description: 'Best passionate romantic hits sung by Sid Sriram',
    coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    songIds: ['aradhya-3', 'geetha-govindam-4', 'radhe-shyam-5'],
    isOffline: false,
    createdAt: '2026-08-22T08:30:00Z'
  },
  {
    id: 'pl-3',
    name: 'Road Trip Love Vibes',
    description: 'Breezy romantic melodies for long highway drives',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    songIds: ['hi-nanna-2', 'jersey-6', 'chaleya-8'],
    isOffline: true,
    createdAt: '2026-08-24T18:15:00Z'
  }
];
