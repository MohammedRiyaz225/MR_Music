/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MusicProvider } from './context/MusicContext';
import { MobileFrame } from './components/MobileFrame';

export default function App() {
  return (
    <MusicProvider>
      <MobileFrame />
    </MusicProvider>
  );
}

